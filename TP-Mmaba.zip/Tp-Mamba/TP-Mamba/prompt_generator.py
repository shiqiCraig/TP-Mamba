# enhanced_prompt_generator.py

from sentence_transformers import SentenceTransformer
import torch
import os


def get_prompt_vectors(dataset_name, device='cuda'):
    """
    Enhanced prompt generator for hyperspectral image classification
    with detailed spectral and spatial characteristics for each dataset
    """
    from sentence_transformers import SentenceTransformer
    import os
    import torch

    prompt_dict = {
        "UP": [
            "Asphalt road surfaces forming linear or paved transportation corridors",

            "Grass meadows with dense green coverage and irregular natural boundaries",

            "Gravel surfaces with scattered stones and rough ground texture",

            "Dense tree canopy with irregular crowns and shadowed areas",

            "Buildings with metal roofs and regular geometric roof shapes",

            "Exposed bare soil with open ground surfaces and sparse vegetation",

            "Bitumen roads appearing as dark linear infrastructure patterns",

            "Residential buildings with clay brick roofs and regular roof geometry",

            "Shadowed areas with dark appearance near buildings, trees, or other objects"
        ],

        "Houston": [
            "Grass areas with healthy green coverage and continuous surface texture",

            "Stressed grass areas with patchy or uneven vegetation",

            "Artificial synthetic grass with uniform green appearance",

            "Tree canopy regions with irregular crown boundaries and shadowed areas",

            "Bare soil surfaces with little or no vegetation coverage",

            "Water bodies with smooth dark surface appearance",

            "Residential buildings with regular roof structures and suburban layouts",

            "Commercial structures with large flat roofs and rectangular building footprints",

            "Asphalt road networks forming linear transportation paths",

            "Highway infrastructure with wide paved lanes and linear markings",

            "Railway tracks with parallel linear features and surrounding gravel",

            "Parking lots with organized rectangular layout and paved surfaces",

            "Secondary parking areas with different surface materials and structured layouts",

            "Tennis courts with rectangular boundaries and managed surface layout",

            "Athletic tracks with oval geometry and regular field layout"
        ],

        "HanChuan": [
            "Strawberry fields with low-growing crops arranged in rows",

            "Cowpea crop areas with climbing vine vegetation and organized planting patterns",

            "Soybean fields with broad leafy canopy and uniform crop coverage",

            "Sorghum fields with tall cereal plants and structured field layout",

            "Water spinach cultivation with leafy semi-aquatic crops",

            "Watermelon fields with sprawling vines and organized planting",

            "Mixed greens cultivation with dense leafy coverage and structured rows",

            "Natural tree areas with dense irregular canopies",

            "Grassland regions with short grass and open land appearance",

            "Rural residential buildings with regular roof structures and scattered settlement patterns",

            "Agricultural buildings with simple shapes and farm-related functions",

            "Greenhouses with protective coverings and organized field layouts",

            "Exposed agricultural soil with open ground and sparse vegetation",

            "Rural roads connecting agricultural parcels with unpaved surfaces",

            "Agricultural equipment and structures with bright surfaces and functional layout",

            "Natural water bodies integrated into agricultural landscapes"
        ],

        "HongHu": [
            "Traditional rural buildings with red clay roofs and regular geometry",

            "Rural roads connecting agricultural areas with linear layout",

            "Exposed bare soil in agricultural fields with open ground surfaces",

            "Cotton fields with organized crop rows and field-scale coverage",

            "Areas with dried crop residues and irregular ground patches",

            "Rape seed fields with organized planting and flowering crop appearance",

            "Chinese cabbage fields with broad leafy coverage and structured planting",

            "Pakchoi fields with compact leafy structure and dense planting",

            "General cabbage fields with large leafy crop coverage and organized rows",

            "Tuber mustard fields with root vegetable crops and orderly planting",

            "Brassica parachinensis fields with leafy vegetables and row planting",

            "Brassica chinensis fields with dense leafy coverage and structured cultivation",

            "Small Brassica chinensis plots with compact crops and high-density planting",

            "Lettuce fields with broad leafy coverage and organized commercial planting",

            "Celtuce fields with stem vegetables and structured agricultural layout",

            "Plastic-covered lettuce plots with protective coverings and orderly layout",

            "Romaine lettuce fields with elongated leaves and commercial planting pattern",

            "Carrot fields with root vegetables arranged in rows",

            "White radish fields with root crops and structured row planting",

            "Garlic sprout fields with narrow leafy crops and organized cultivation",

            "Broad bean fields with legume crops and regular agricultural rows",

            "Natural tree areas with dense irregular canopies and unmanaged vegetation"
        ]
    }

    prompts = prompt_dict.get(dataset_name)
    if prompts is None:
        available_datasets = list(prompt_dict.keys())
        raise ValueError(f"[Error] Unknown dataset name: {dataset_name}. Available datasets: {available_datasets}")

    expected_classes = {
        "UP": 9,
        "Houston": 15,
        "HanChuan": 16,
        "HongHu": 22
    }

    if len(prompts) != expected_classes[dataset_name]:
        print(
            f"[Warning] Number of prompts ({len(prompts)}) doesn't match expected classes ({expected_classes[dataset_name]}) for {dataset_name}")

    current_dir = os.path.dirname(os.path.abspath(__file__))
    model_path = os.path.join(current_dir, "all-MiniLM-L6-v2")

    try:
        model = SentenceTransformer(model_path).to(device)
        print(f"[Info] Loaded local model from {model_path}")
    except Exception as e:
        print(f"[Warning] Failed to load local model: {e}")
        print("[Info] Falling back to download model...")
        model = SentenceTransformer('all-MiniLM-L6-v2').to(device)

    embeddings = model.encode(
        prompts,
        convert_to_tensor=True,
        normalize_embeddings=True,
        show_progress_bar=True
    ).to(device)

    print(f"[Info] Generated embeddings shape: {embeddings.shape} for {dataset_name} dataset")

    return embeddings


def get_dataset_info(dataset_name):
    dataset_info = {
        "UP": {
            "full_name": "Pavia University",
            "sensor": "ROSIS",
            "bands": 103,
            "spatial_size": "610 × 340",
            "classes": 9,
            "scene_type": "Urban university campus"
        },
        "Houston": {
            "full_name": "University of Houston",
            "sensor": "ITRES CASI 1500",
            "bands": 144,
            "spatial_size": "349 × 1905",
            "classes": 15,
            "scene_type": "Urban campus and residential"
        },
        "HanChuan": {
            "full_name": "WHU-Hi-HanChuan",
            "sensor": "Headwall Nano-Hyperspec",
            "bands": 274,
            "spatial_size": "1217 × 303",
            "classes": 16,
            "scene_type": "Rural-urban fringe agriculture"
        },
        "HongHu": {
            "full_name": "WHU-Hi-HongHu",
            "sensor": "Headwall Nano-Hyperspec",
            "bands": 270,
            "spatial_size": "940 × 475",
            "classes": 22,
            "scene_type": "Complex agricultural scene"
        }
    }

    return dataset_info.get(dataset_name, {})


if __name__ == "__main__":
    device = 'cuda' if torch.cuda.is_available() else 'cpu'

    for dataset in ["UP", "Houston", "HanChuan", "HongHu"]:
        print(f"\n{'=' * 50}")
        print(f"Processing {dataset} dataset...")
        info = get_dataset_info(dataset)
        print(f"Dataset: {info.get('full_name', 'Unknown')}")
        print(f"Sensor: {info.get('sensor', 'Unknown')}")
        print(f"Bands: {info.get('bands', 'Unknown')}")
        print(f"Classes: {info.get('classes', 'Unknown')}")
        try:
            embeddings = get_prompt_vectors(dataset, device)
            print(f"Successfully generated embeddings: {embeddings.shape}")
        except Exception as e:
            print(f"Error processing {dataset}: {e}")
