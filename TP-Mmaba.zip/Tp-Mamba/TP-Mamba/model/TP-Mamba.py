# #200608
import torch
import torch.nn as nn
import math
from mamba_ssm import Mamba
import torch.nn.functional as F
from prompt_generator import get_prompt_vectors

class MinPool1D(nn.Module):
    def __init__(self, kernel_size=3, stride=1, padding=1):
        super(MinPool1D, self).__init__()
        self.kernel_size = kernel_size
        self.stride = stride
        self.padding = padding

    def forward(self, x):
        return -F.max_pool1d(-x, kernel_size=self.kernel_size, stride=self.stride, padding=self.padding)

class Morphology1D(nn.Module):
    def __init__(self, channels, kernel_size=3):
        super(Morphology1D, self).__init__()
        padding = kernel_size // 2
        self.morph = nn.Sequential(
            nn.Conv1d(channels, channels, kernel_size=kernel_size, padding=padding,
                      groups=channels, bias=False),
            nn.BatchNorm1d(channels),
            nn.ReLU(inplace=True),
            nn.MaxPool1d(kernel_size=kernel_size, stride=1, padding=padding),
            MinPool1D(kernel_size=kernel_size, stride=1, padding=padding)
        )

    def forward(self, x):
        return self.morph(x)

class SEBlock(nn.Module):
    def __init__(self, channels, reduction=16):
        super(SEBlock, self).__init__()
        self.pool = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Sequential(
            nn.Linear(channels, channels // reduction, bias=False),
            nn.ReLU(inplace=True),
            nn.Linear(channels // reduction, channels, bias=False),
            nn.Sigmoid()
        )

    def forward(self, x):
        b, c, _, _ = x.size()
        y = self.pool(x).view(b, c)
        y = self.fc(y).view(b, c, 1, 1)
        return x * y

class PromptCrossAttention(nn.Module):
    def __init__(self, feat_dim, prompt_input_dim, num_classes, heads=4):
        super().__init__()
        self.num_classes = num_classes
        self.project_prompt = nn.Linear(prompt_input_dim, feat_dim)  # 用真实维度 384
        self.attn = nn.MultiheadAttention(embed_dim=feat_dim, num_heads=heads, batch_first=True)
        self.fusion = nn.Sequential(
            nn.Conv2d(feat_dim, feat_dim, kernel_size=1),
            nn.SiLU()
        )

    def forward(self, x, prompt_vecs, prompt_scale=None):
        B, C, H, W = x.shape
        x_flat = x.view(B, C, -1).permute(0, 2, 1)

        if prompt_scale is not None:
            prompt_vecs = prompt_vecs * prompt_scale.unsqueeze(-1)

        prompts = self.project_prompt(prompt_vecs)
        prompts = prompts.unsqueeze(0).repeat(B, 1, 1)

        attn_output, _ = self.attn(query=prompts, key=x_flat, value=x_flat)
        prompt_feature = attn_output.mean(dim=1).unsqueeze(-1).unsqueeze(-1)

        prompt_feature = self.fusion(prompt_feature)
        return prompt_feature

class SpeMamba(nn.Module):
    def __init__(self, channels, token_num=8, use_residual=True, group_num=4, kernel_size=5):
        super(SpeMamba, self).__init__()
        self.token_num = token_num
        self.use_residual = use_residual
        self.group_channel_num = math.ceil(channels / token_num)
        self.channel_num = self.token_num * self.group_channel_num


        self.mamba = Mamba(
            d_model=self.group_channel_num,
            d_state=16,
            d_conv=4,
            expand=2,
        )

        self.proj = nn.Sequential(
            nn.GroupNorm(group_num, self.channel_num),
            nn.SiLU()
        )

        self.morph = Morphology1D(channels, kernel_size=kernel_size)

        self.se = SEBlock(channels)

    def padding_feature(self, x):
        B, C, H, W = x.shape
        if C < self.channel_num:
            pad_c = self.channel_num - C
            pad_features = torch.zeros((B, pad_c, H, W), device=x.device)
            x = torch.cat([x, pad_features], dim=1)
        return x

    def forward(self, x):
        x_pad = self.padding_feature(x)
        x_pad = x_pad.permute(0, 2, 3, 1).contiguous()
        B, H, W, C_pad = x_pad.shape

        x_flat = x_pad.view(B * H * W, self.token_num, self.group_channel_num)
        x_flat = self.mamba(x_flat)

        x_morph = x.view(B, -1, H * W)
        x_morph = x_morph.view(B, -1, H, W)

        x_proj = self.proj(x_morph)

        return x + x_proj if self.use_residual else x_proj

class MinPool2D(nn.Module):
    def __init__(self, kernel_size=3, stride=1, padding=1):
        super(MinPool2D, self).__init__()
        self.kernel_size = kernel_size
        self.stride = stride
        self.padding = padding

    def forward(self, x):
        return -F.max_pool2d(-x, kernel_size=self.kernel_size, stride=self.stride, padding=self.padding)

class Morphology2D(nn.Module):
    def __init__(self, channels, kernel_size=3):
        super(Morphology2D, self).__init__()
        padding = kernel_size // 2

        self.morph = nn.Sequential(
            nn.Conv2d(channels, channels, kernel_size=kernel_size, padding=padding, groups=channels, bias=False),
            nn.BatchNorm2d(channels),
            nn.ReLU(inplace=True),

            nn.MaxPool2d(kernel_size=kernel_size, stride=1, padding=padding),

            MinPool2D(kernel_size=kernel_size, stride=1, padding=padding)
        )
    def forward(self, x):
        return self.morph(x)
class SpaMamba(nn.Module):
    def __init__(self, channels, use_residual=True, group_num=4, use_proj=True):
        super(SpaMamba, self).__init__()
        self.use_residual = use_residual
        self.use_proj = use_proj

        self.mamba = Mamba(
            d_model=channels,
            d_state=16,
            d_conv=4,
            expand=2,
        )

        if self.use_proj:
            self.proj = nn.Sequential(
                nn.GroupNorm(group_num, channels),
                nn.SiLU()
            )

        self.morph = Morphology2D(channels, kernel_size=5)

        self.se = SEBlock(channels)



    def forward(self, x):
        B, C, H, W = x.shape
        x_re = x.permute(0, 2, 3, 1).contiguous().view(B, H * W, C)

        x_flat = self.mamba(x_re)

        x_recon = x_flat.view(B, H, W, C).permute(0, 3, 1, 2).contiguous()

        if self.use_proj:
            x_recon = self.proj(x_recon)

        return x_recon + x if self.use_residual else x_recon


class BothMamba(nn.Module):
    def __init__(self, channels, token_num, use_residual, group_num=4, use_att=True):
        super(BothMamba, self).__init__()
        self.use_att = use_att
        self.use_residual = use_residual

        if self.use_att:
            self.weights = nn.Parameter(torch.ones(2) / 2)
            self.softmax = nn.Softmax(dim=0)

        self.spa_mamba = SpaMamba(channels, use_residual=use_residual, group_num=group_num)
        self.spe_mamba = SpeMamba(
            channels,
            token_num=token_num,
            use_residual=use_residual,
            group_num=group_num
        )

    def forward(self, x):
        spa_x = self.spa_mamba(x)
        spe_x = self.spe_mamba(x)

        if self.use_att:
            weights = self.softmax(self.weights)
            fusion_x = spa_x * weights[0] + spe_x * weights[1]
        else:
            fusion_x = spa_x + spe_x

        return fusion_x + x if self.use_residual else fusion_x


class MambaHSI(nn.Module):
    def __init__(self, in_channels, hidden_dim=64, num_classes=10, use_residual=True,
                 mamba_type='both', token_num=4, group_num=4, use_att=True,
                 spectral_data=None, n_clusters=3, device='cuda', data_set_name='UP'):
        super(MambaHSI, self).__init__()

        self.mamba_type = mamba_type
        self.spectral_segments = n_clusters

        self.patch_embedding = nn.Sequential(
            nn.Conv2d(in_channels=in_channels, out_channels=hidden_dim,
                      kernel_size=1, stride=1, padding=0),
            nn.GroupNorm(group_num, hidden_dim),
            nn.SiLU()
        )

        # 使用新的 Mamba 模块构建序列
        if mamba_type == 'spa':
            self.mamba = nn.Sequential(
                SpaMamba(hidden_dim, use_residual=use_residual, group_num=group_num),
                nn.AvgPool2d(kernel_size=2, stride=2, padding=0),
                SpaMamba(hidden_dim, use_residual=use_residual, group_num=group_num),
                nn.AvgPool2d(kernel_size=2, stride=2, padding=0),
                SpaMamba(hidden_dim, use_residual=use_residual, group_num=group_num),
            )
        elif mamba_type == 'spe':
            self.mamba = nn.Sequential(
                SpeMamba(hidden_dim, token_num=token_num, use_residual=use_residual,
                         group_num=group_num),
                nn.AvgPool2d(kernel_size=2, stride=2, padding=0),
                SpeMamba(hidden_dim, token_num=token_num, use_residual=use_residual,
                         group_num=group_num),
                nn.AvgPool2d(kernel_size=2, stride=2, padding=0),
                SpeMamba(hidden_dim, token_num=token_num, use_residual=use_residual,
                         group_num=group_num)
            )
        elif mamba_type == 'both':
            self.mamba = nn.Sequential(
                BothMamba(channels=hidden_dim, token_num=token_num, use_residual=use_residual,
                          group_num=group_num, use_att=use_att),
                nn.AvgPool2d(kernel_size=2, stride=2, padding=0),
                BothMamba(channels=hidden_dim, token_num=token_num, use_residual=use_residual,
                          group_num=group_num, use_att=use_att),
                nn.AvgPool2d(kernel_size=2, stride=2, padding=0),
                BothMamba(channels=hidden_dim, token_num=token_num, use_residual=use_residual,
                          group_num=group_num, use_att=use_att),
            )


        self.cls_head = nn.Sequential(
            nn.Conv2d(in_channels=hidden_dim, out_channels=128, kernel_size=1, stride=1, padding=0),
            nn.GroupNorm(group_num, 128),
            nn.SiLU(),
            nn.Conv2d(in_channels=128, out_channels=num_classes, kernel_size=1, stride=1, padding=0)
        )

        self.prompt_vecs_stages = nn.ParameterList([
            nn.Parameter(get_prompt_vectors(data_set_name, device=device))
            for _ in range(3)
        ])
        self.prompt_scale_stages = nn.ParameterList([
            nn.Parameter(torch.ones(num_classes, device=device))
            for _ in range(3)
        ])
        self.prompt_attention = PromptCrossAttention(
            feat_dim=hidden_dim,
            prompt_input_dim=self.prompt_vecs_stages[0].shape[1],
            num_classes=num_classes
        )


        self.spatial_conv1 = nn.Conv2d(hidden_dim, hidden_dim, kernel_size=3, padding=1)
        self.spatial_conv2 = nn.Conv2d(hidden_dim, hidden_dim, kernel_size=3, padding=1)
        self.spatial_conv3 = nn.Conv2d(hidden_dim, hidden_dim, kernel_size=3, padding=1)

        self.alpha1 = nn.Parameter(torch.tensor(0.3))
        self.alpha2 = nn.Parameter(torch.tensor(0.3))
        self.alpha3 = nn.Parameter(torch.tensor(0.4))

    def forward(self, x, return_features=False):
        drop_prob = 0.2

        x = self.patch_embedding(x)

        x = self.mamba[0](x)

        global_prompt = torch.mean(self.prompt_vecs_stages[0], dim=0, keepdim=True)

        prompt1 = self.prompt_attention(x, global_prompt, self.prompt_scale_stages[0])
        if self.training:
            mask = (torch.rand(prompt1.shape[0], device=prompt1.device) > drop_prob).float().view(-1, 1, 1, 1)
            prompt1 = prompt1 * mask
        spatial_map1 = torch.sigmoid(self.spatial_conv1(x))
        x = x + self.alpha1 * (prompt1.expand_as(x) * spatial_map1)

        x = self.mamba[1](x)  # pool

        x = self.mamba[2](x)

        global_prompt2 = torch.mean(self.prompt_vecs_stages[1], dim=0, keepdim=True)

        prompt2 = self.prompt_attention(x, global_prompt2, self.prompt_scale_stages[1])
        if self.training:
            mask = (torch.rand(prompt2.shape[0], device=prompt2.device) > drop_prob).float().view(-1, 1, 1, 1)
            prompt2 = prompt2 * mask
        spatial_map2 = torch.sigmoid(self.spatial_conv2(x))
        x = x + self.alpha2 * (prompt2.expand_as(x) * spatial_map2)

        x = self.mamba[3](x)

        x = self.mamba[4](x)
        if return_features:
            feature_before = x.clone()

        global_prompt3 = torch.mean(self.prompt_vecs_stages[2], dim=0, keepdim=True)
        prompt3 = self.prompt_attention(x, global_prompt3, self.prompt_scale_stages[2])
        if self.training:
            mask = (torch.rand(prompt3.shape[0], device=prompt3.device) > drop_prob).float().view(-1, 1, 1, 1)
            prompt3 = prompt3 * mask
        spatial_map3 = torch.sigmoid(self.spatial_conv3(x))
        x = x + self.alpha3 * (prompt3.expand_as(x) * spatial_map3)

        if return_features:
            feature_after = x.clone()

        logits = self.cls_head(x)

        if return_features:
            return logits, feature_before, feature_after

        return logits