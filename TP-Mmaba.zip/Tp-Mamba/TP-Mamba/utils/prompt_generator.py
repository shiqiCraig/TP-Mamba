# prompt_generator.py

from sentence_transformers import SentenceTransformer
import torch

def get_prompt_vectors(dataset_name, device='cuda'):
    prompt_dict = {
        "UP": [
            "This is asphalt road",
            "This is a grassy meadow",
            "This area contains trees",
            "This is a metal roof",
            "This is a bare soil area",
            "This is a bitumen-covered road",
            "This is a brick roof",
            "This is a shadowed region",
            "This is a block-paved area"
        ],
        "Houston": [
            "This is a residential area",
            "This is a commercial building",
            "This is a road surface",
            "This is grass",
            "This is a tree canopy",
            "This is a sidewalk",
            "This is a parking lot",
            "This is bare land",
            "This is a water body",
            "This is a highway"
        ],
        "HanChuan": [
            "This is rice",
            "This is cotton",
            "This is forest land",
            "This is water",
            "This is residential area",
            "This is corn field"
        ],
        "HongHu": [
            "This is lotus pond",
            "This is water",
            "This is farmland",
            "This is residential area",
            "This is reed wetland",
            "This is woodland"
        ]
    }

    prompts = prompt_dict.get(dataset_name)
    if prompts is None:
        raise ValueError(f"Unknown dataset name: {dataset_name}")

    model = SentenceTransformer("all-MiniLM-L6-v2").to(device)
    embeddings = model.encode(prompts, normalize_embeddings=True)
    return torch.tensor(embeddings, dtype=torch.float32).to(device)
